import UIKit
//sortedArray
let nums = [1,3,5,6,7,8,19,21,34,56,78]
//divide array in half and look for val in both halves

func binarySearch(searchVal: Int, array: [Int]) -> Bool {
    var leftIndex = 0
    var rightIndex = array.count - 1
    
    while leftIndex <= rightIndex {
        
        let middleIndex = (leftIndex + rightIndex) / 2
        let middleValue = array[middleIndex]
        if middleValue == searchVal {
            return true
        }
        if searchVal < middleValue {
            rightIndex = middleIndex - 1
        } else {
            leftIndex = middleIndex + 1
        }
        
    }
    return false

}

print(binarySearch(searchVal: 34, array: nums))

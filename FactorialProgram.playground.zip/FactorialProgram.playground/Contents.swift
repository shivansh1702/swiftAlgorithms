import UIKit

//func printFactorial(value: UInt) -> UInt {
//    
//    if value == 0 {
//        return 1
//    }
//    
//    var product: UInt = 1
//    for i in 1...value {
//        product = product * i
//    }
//    
//    return product
//}

func recursiveFactorial(value: UInt) -> UInt {
    
    if value == 0 {
        return 1
    }
    
    return value * recursiveFactorial(value: value - 1)
    
}
//print(printFactorial(value: 0))
print(recursiveFactorial(value: 4))

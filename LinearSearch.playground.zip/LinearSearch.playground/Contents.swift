import UIKit

let numbers = [1,3,4,6,79,29,34546,5653434,38,5,78]

func linearSearchForVal(searchValue: Int, array: [Int]) -> Bool {
    for num in array {
        if num == searchValue {
            return true
        }
    }
    return false
}
print(linearSearchForVal(searchValue: 5, array: numbers))

// Singleton Points
// 1. Only one instance/object of a class is allowed. -> present/declared/defined inside the class itself.
// ** GLobal Access of the above single/static instance of the class. **
// 2. Private initializer(to prevent creation of any other object outside of the class.)
// 3. static keyword
// 4. helpful in memory management.
//

//You can have important data. So, sometimes, someone else may require some part of your data, not all of it. So consider Singleton as a member that gives you the required data by being a medium rather than you dealing with multiple people individually.
